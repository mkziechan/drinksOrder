/*
 CS 110B - Honor Project - 2019 FALL
 @author Mackenzie(Yingjie) Chen - student ID: W10745258
 Professor: Maximilian Luttrell
 */

#include <iostream>
#include <string>
#include "orderRecord.h"
#include "singleOrder.h"
#include "SimpleAudioEngine.h"
using namespace std;

USING_NS_CC;


orderRecord::orderRecord()
{
    singleOrder s;
    orders[numOfOrders] = s;
    numOfOrders = 0;
}

orderRecord::orderRecord(singleOrder s) {
    orders[numOfOrders] = s;
    numOfOrders = 0;
}



void orderRecord::setOneDrink(singleOrder s)
{
    if (numOfOrders < SIZE)
    {
        orders[numOfOrders] = s;
        numOfOrders++;
        getTotalOrders();
    }
    else
    {
        cout << "\nSorry. Your order has reached the maximum number: 10.\n";
    }
    
}

void orderRecord::resetLastDrinkIce(string i)
{
    if (numOfOrders <= SIZE && numOfOrders > 0)
    {
        orders[numOfOrders-1].setIce(i);
    }
    getTotalOrders();
}

void orderRecord::resetLastDrinkSweet(string s)
{
    if (numOfOrders <= SIZE && numOfOrders > 0)
    {
        orders[numOfOrders-1].setSweet(s);
    }
    getTotalOrders();
}


float orderRecord::getTotalPrice()
{
    double totalPrice = 0.0;
    if(numOfOrders <= SIZE && numOfOrders >= 0)
    {
        totalPrice = numOfOrders * PRICE_SINGLE_DRINKS;
    }
    return totalPrice;
}

void orderRecord::getTotalOrders()
{
    if(numOfOrders > 0) {
        cout << "\n\t*********** Your order: ***********\n";
        for(int i=0; i<numOfOrders; i++)
        {
            cout << i+1 << ". ";
            orders[i].printOrder();
        }
        cout << "\n\t\t\t\tTotal Price: $" << getTotalPrice() << "\n";
        cout << "\t******************************\n\n";
    }
}

string orderRecord::getOneRecord()
{
    string tempDrink = "\t\t\t\t\t\t****** Your order: ******\n";
    for(int i=0; i<numOfOrders; i++)
    {
        tempDrink += (to_string(i+1) + ". ");
        tempDrink += orders[i].getOrder();
    }
    return tempDrink;
}


    

    
    
    

