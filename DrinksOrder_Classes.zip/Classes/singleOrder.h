/*
 CS 110B - Honor Project - 2019 FALL
 @author Mackenzie(Yingjie) Chen - student ID: W10745258
 Professor: Maximilian Luttrell
 */

#ifndef __singleOrder__
#define __singleOrder__

#include "cocos2d.h"
#include <iostream>
#include <functional>

using namespace std;

class singleOrder
{
private:
    string ice, sweet, drinkName;
    
public:
    singleOrder();
    singleOrder(string name, string ice, string sweet);
    void setIce(string);
    void setSweet(string);
    void setName(string);
    void printOrder() {
        cout << drinkName << ":\n\t\t" << ice << ", " << sweet << ".\n";
    }
    string getOrder() {
        return (drinkName + ": " + ice + ", " + sweet + ".\n");
    }
    
    
    
};

#endif //_singleOrder_
