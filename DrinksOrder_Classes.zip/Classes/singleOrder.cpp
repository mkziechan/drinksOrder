/*
 CS 110B - Honor Project - 2019 FALL
 @author Mackenzie(Yingjie) Chen - student ID: W10745258
 Professor: Maximilian Luttrell
 */
#include <iostream>
#include "singleOrder.h"
#include "SimpleAudioEngine.h"
using namespace std;

USING_NS_CC;


singleOrder::singleOrder() {
    ice = sweet = drinkName = " ";
}

singleOrder::singleOrder(string n, string i, string s) {
    drinkName = n;
    ice = i;
    sweet = s;
}

void singleOrder::setIce(string i)
{
    ice = i;
}
void singleOrder::setSweet(string s)
{
    sweet = s;
}

void singleOrder::setName(string n)
{
    drinkName = n;
}



