/****************************************************************************
 Copyright (c) 2017-2018 Xiamen Yaji Software Co., Ltd.
 
 http://www.cocos2d-x.org
 
 Permission is hereby granted, free of charge, to any person obtaining a copy
 of this software and associated documentation files (the "Software"), to deal
 in the Software without restriction, including without limitation the rights
 to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:
 
 The above copyright notice and this permission notice shall be included in
 all copies or substantial portions of the Software.
 
 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 THE SOFTWARE.
 ****************************************************************************/

/*
 CS 110B - Honor Project - 2019 FALL
 @author Mackenzie(Yingjie) Chen - student ID: W10745258
 Professor: Maximilian Luttrell
 */

#include "HelloWorldScene.h"
#include "JasScene.h"
#include "greenScene.h"
#include "blackScene.h"
#include "Check.h"
#include "singleOrder.h"
#include "orderRecord.h"

USING_NS_CC;

singleOrder s("", "", "");
orderRecord Order(s);
orderRecord* currentOrder = &Order;

Scene* HelloWorld::createScene()
{
    return HelloWorld::create();
}

// Print useful error message instead of segfaulting when files are not there.
static void problemLoading(const char* filename)
{
    printf("Error while loading: %s\n", filename);
    printf("Depending on how you compiled you might have to add 'Resources/' in front of filenames in HelloWorldScene.cpp\n");
}

// on "init" you need to initialize your instance
bool HelloWorld::init()
{
    //////////////////////////////
    // 1. super init first
    if ( !Scene::init() )
    {
        return false;
    }

    auto visibleSize = Director::getInstance()->getVisibleSize();
    Vec2 origin = Director::getInstance()->getVisibleOrigin();
    
    
    mySprite = Sprite::create("HelloWorld.jpg");
    mySprite->setPosition(Point((visibleSize.width / 2) + origin.x, (visibleSize.height / 2) + origin.y));
    this->addChild(mySprite);
    
    
    
    //single touch
    auto listener = EventListenerTouchOneByOne::create();
    listener->setSwallowTouches(true);
    
    listener->onTouchBegan = CC_CALLBACK_2(HelloWorld::onTouchBegan, this);
    listener->onTouchMoved = CC_CALLBACK_2(HelloWorld::onTouchMoved, this);
    listener->onTouchEnded = CC_CALLBACK_2(HelloWorld::onTouchEnded, this);
    
    
    _eventDispatcher->addEventListenerWithSceneGraphPriority(listener, this);
   

    //adding a menu item
    auto menu_item_1 = MenuItemFont::create("Jasmine Milk Tea", CC_CALLBACK_1(HelloWorld::JasmineMilkTea, this));
    auto menu_item_2 = MenuItemFont::create("Black Milk Tea", CC_CALLBACK_1(HelloWorld::BlackMilkTea, this));
    auto menu_item_3 = MenuItemFont::create("Green Milk Tea", CC_CALLBACK_1(HelloWorld::GreenMilkTea, this));
    
    
    
    //set the position of above three items
    menu_item_1->setPosition(Point( (visibleSize.width / 4) * 1, (visibleSize.height / 4) * 3 ));
    menu_item_2->setPosition(Point( (visibleSize.width / 4) * 2, (visibleSize.height / 4) * 2 ));
    menu_item_3->setPosition(Point( (visibleSize.width / 4) * 3, (visibleSize.height / 4) * 1 ));
   
    //menu
    auto *menu = Menu::create(menu_item_1, menu_item_2, menu_item_3, NULL);
    menu->setPosition(Point(0, 0));
    this->addChild(menu);
  
    
    return true;
    

}

void HelloWorld::JasmineMilkTea(cocos2d::Ref *pSender)
{
    
    auto scene = JasScene::createScene(currentOrder);
    
    Director::getInstance()->pushScene(scene);
    
}

void HelloWorld::BlackMilkTea(cocos2d::Ref *pSender)
{
    
    auto scene = blackScene::createScene(currentOrder);
    
    Director::getInstance()->pushScene(scene);
    
}

void HelloWorld::GreenMilkTea(cocos2d::Ref *pSender)
{
    
    auto scene = greenScene::createScene(currentOrder);
    
    Director::getInstance()->pushScene(scene);
    
}

bool HelloWorld::onTouchBegan(cocos2d::Touch *touch, cocos2d::Event *event)
{
    CCLOG("onTouchBegan x = %f, y = %f", touch->getLocation().x, touch->getLocation().y);
    
    return true;
}

void HelloWorld::onTouchMoved(cocos2d::Touch *touch, cocos2d::Event *event)
{
    CCLOG("onTouchMoved x = %f, y = %f", touch->getLocation().x, touch->getLocation().y);
}

void HelloWorld::onTouchEnded(cocos2d::Touch *touch, cocos2d::Event *event)
{
    CCLOG("onTouchEnded x = %f, y = %f", touch->getLocation().x, touch->getLocation().y);
}


void HelloWorld::menuCloseCallback(Ref* pSender)
{
    //Close the cocos2d-x game scene and quit the application
    Director::getInstance()->end();
    
//    Scene* tempScene = JasScene::createScene(currentOrder);
//    Director::getInstance()->replaceScene(tempScene);

    
    /*To navigate back to native iOS screen(if present) without quitting the application  ,do not use Director::getInstance()->end() as given above,instead trigger a custom event created in RootViewController.mm as below*/

    //EventCustom customEndEvent("game_scene_close_event");
    //_eventDispatcher->dispatchEvent(&customEndEvent);

}
