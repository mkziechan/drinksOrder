/*
 CS 110B - Honor Project - 2019 FALL
 @author Mackenzie(Yingjie) Chen - student ID: W10745258
 Professor: Maximilian Luttrell
 */

#ifndef __orderRecord__
#define __orderRecord__

#include "cocos2d.h"
#include "singleOrder.h"
#include <iostream>

using namespace std;

class orderRecord
{
    
private:
    static const int SIZE = 10;
    static constexpr float PRICE_SINGLE_DRINKS = 4.75;
    int numOfOrders;
    singleOrder orders[SIZE];
    
public:

    orderRecord();
    ~orderRecord() = default;
    orderRecord(singleOrder);
    void setOneDrink(singleOrder);
    void resetLastDrinkIce(string);
    void resetLastDrinkSweet(string);
    void getTotalOrders();
    float getTotalPrice();
    int getNumOfOrders()
    { return numOfOrders;}
    string getOneRecord();

};

#endif //__orderRecord__
